package com.bihara.rentcloud.authenticationserver.repository;

import com.bihara.rentcloud.authenticationserver.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserDetailRepository extends JpaRepository<User, Integer> {
    // Optional<User> findByUserName(String name);
    Optional<User> findByUserName(String name);
}
