package com.bihara.rentcloud.profileservice.service;

import org.bihara.rentcloud.model.Customer;

public interface CustomerService {
    Customer save(Customer customer);
}
