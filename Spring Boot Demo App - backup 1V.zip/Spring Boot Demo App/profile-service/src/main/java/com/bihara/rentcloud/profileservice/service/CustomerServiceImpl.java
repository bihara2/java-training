package com.bihara.rentcloud.profileservice.service;

import com.bihara.rentcloud.profileservice.repository.CustomerRepository;
import org.bihara.rentcloud.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerServiceImpl implements CustomerService{

    @Autowired
    CustomerRepository customerRepository;

    @Override
    public Customer save(Customer customer) {

        return customerRepository.save(customer);
    }
}
