package com.rentcloud.rentcloudconfigserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentcloudConfigServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
